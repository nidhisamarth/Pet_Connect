export const test= (req,res) => {

res.json({
    message:'Hello World',
})
}
